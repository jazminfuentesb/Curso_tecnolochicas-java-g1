package org.bedu.uci_monitoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UciMonitoringApplicationTests {

	@Test
	void contextLoads() {
	}

}
