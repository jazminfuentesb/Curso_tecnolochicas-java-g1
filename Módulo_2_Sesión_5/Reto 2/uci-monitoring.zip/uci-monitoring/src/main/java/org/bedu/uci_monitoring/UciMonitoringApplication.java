package org.bedu.uci_monitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UciMonitoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(UciMonitoringApplication.class, args);
	}

}
