package org.bedu.meridian_prime_control;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeridianPrimeControlApplicationTests {

	@Test
	void contextLoads() {
	}

}
