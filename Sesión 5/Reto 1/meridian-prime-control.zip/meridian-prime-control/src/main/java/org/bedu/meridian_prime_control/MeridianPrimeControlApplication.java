package org.bedu.meridian_prime_control;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeridianPrimeControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeridianPrimeControlApplication.class, args);
	}

}
